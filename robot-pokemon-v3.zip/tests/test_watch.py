"""Test del robot con negozi finti (Shopify e WooCommerce), TCGdex finto e Telegram finto.

Uso: python tests/test_watch.py
"""
import json
import os
import sys
import tempfile
from datetime import date, datetime
from pathlib import Path
from urllib.parse import unquote

sys.path.insert(0, str(Path(__file__).parent.parent))
import market  # noqa: E402
import watch  # noqa: E402

watch.time.sleep = lambda s: None
TMP = Path(tempfile.mkdtemp())
TODAY = date(2026, 9, 28)


def test_classify():
    c = watch.classify
    assert c("Pokémon Dominio Delta Set Allenatore Fuoriclasse ITA") == "Set Allenatore"
    assert c("Megaevoluzione Buio Pesto Display 36 Buste (IT)") == "Box 36 buste"
    assert c("Pokémon 30° Anniversario Bundle 6 Bustine ITA") == "Bundle 6 buste"
    assert c("Pokémon Ultra Premium Umbreon 30° Anniversario ITA") == "Ultra Premium"
    assert c("Pokémon 30° Anniversario Collezione Premium Ditto ITA") == "Collezione Premium"
    assert c("Megaevoluzione Caos Nascente Factory Sealed Case (x6 Display IT)") is None
    assert c("Pokemon 30th Celebration Booster Bundle ENG") is None
    assert c("Mega Rayquaza ex 123/135 Dominio Delta") is None
    assert c("Dominio Delta – Bustina singola") is None
    assert c("GAMEVISION Pokemon Megaevoluzione Buio Pesto Busta Blister") is None
    assert c("Premium Checklane Blister di Avventure Insieme: Klinklang") is None
    assert c("Pokémon 30° Anniversario – Bundle del Collezionista 2 – Italiano") is None
    assert c("Bundle 2 Tin da Collezione Sylveon-ex + Greninja-ex - 30° Anniversario (ITA)") is None
    assert c("Funko Pop Premium Games Pokemon Ivysaur") is None


def test_variant():
    v = watch.variant
    assert v("Collezione Ultra Premium 30° Anniversario Serata Umbreon (ITA)", "Ultra Premium") == "Umbreon"
    assert v("Pokémon 30th - Collezione con Poster ITA", "Collezione") == "Poster"
    assert v("Collezione Poster Pokémon 30° Anniversario IT | Articuno, Zapdos e Moltres", "Collezione") == "Poster"
    assert v("Dominio Delta Set Allenatore Fuoriclasse ETB Mega Rayquaza (ITA)", "Set Allenatore") == ""
    assert v("30° Anniversario Set Allenatore Fuoriclasse Pokémon Center (ITA)", "Set Allenatore") == "Pokémon Center"
    assert v("Tin da Collezione 30° Anniversario: Greninja-ex", "Tin") == "Greninja"


def test_dates_and_status():
    f = watch.find_release_date
    assert f("Uscita prevista: 6 novembre 2026", TODAY) == date(2026, 11, 6)
    assert f("Uscita prevista: 27/03/2026", TODAY) is None  # data passata rimasta nella scheda
    assert f("Disponibile dal 02/10", TODAY) == date(2026, 10, 2)
    assert f("Offerta valida fino al 30/11/2026", TODAY) is None
    assert f("uscita 1/2 buste", TODAY) is None
    assert f("Uscita prevista: 27/03", TODAY) is None  # senza anno e già passata: non l'anno prossimo
    assert f("Uscita prevista il 15 gennaio", TODAY) == date(2027, 1, 15)
    assert f("Spedizione gratuita fino al 31/10/2026", TODAY) is None
    cfg = {"set": [{"nome": "A", "uscita": "2026-11-06", "certo": True},
                   {"nome": "B", "uscita": "2026-03-27", "certo": True},
                   {"nome": "S", "uscita": "2026-09-16", "certo": True, "speciale": True}],
           "calendario": [{"data": "2026-11-06", "set": "S", "cosa": "Ultra Premium Umbreon e Espeon"}]}
    st = lambda **o: watch.status(o, cfg, TODAY)  # noqa: E731
    assert st(set="A", comprabile=True) == "preordine"
    assert st(set="A", comprabile=False) == "in_arrivo"
    assert st(set="B", comprabile=True, preordine=True) == "disponibile"  # "preordine" rimasto nel titolo
    assert st(set="B", comprabile=False) == "esaurito"
    up = dict(set="S", tipo="Ultra Premium", titolo="Ultra Premium Umbreon ITA", comprabile=True, preordine=True)
    assert st(**up) == "preordine"  # ondata successiva di un set speciale, prevista dal calendario
    assert st(**{**up, "tipo": "Tin", "titolo": "Tin Greninja ITA"}) == "disponibile"  # "preordine" rimasto
    assert st(set="B", comprabile=True, uscita="2026-12-04") == "preordine"


def test_split():
    text = "\n\n".join("riga " * 300 for _ in range(6))
    parts = watch.split_message(text, 3900)
    assert all(len(p) <= 3900 for p in parts) and "".join(parts).replace("\n", "") == text.replace("\n", "")


# ------------------------------------------------------------------ mondo finto

class R:
    def __init__(self, data, code=200):
        self.data, self.status_code = data, code

    def json(self):
        return self.data

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(self.status_code)


TCG_SETS = [{"id": "me05", "name": "Pitch Black"}]
TCG_CARDS = {f"me05-{i}": {"id": f"me05-{i}", "name": n, "rarity": r,
                           "pricing": {"cardmarket": {"trend": p}}}
             for i, (n, r, p) in enumerate([("Pidgey", "Common", 0.02)] * 40 + [("Rattata", "Uncommon", 0.05)] * 30 +
                                           [("Onix", "Rare", 0.2)] * 20 + [("Darkrai ex", "Double rare", 2.0)] * 10 +
                                           [("Umbreon", "Illustration rare", 8.0)] * 10 +
                                           [("Mega Darkrai ex", "Ultra Rare", 6.0)] * 8 +
                                           [("Mega Darkrai ex SIR", "Special illustration rare", 120.0)] * 5)}


def make_session(world):
    """world: {sito: [prodotti] | "blocked"}; prodotto: titolo, h, comprabile, prezzo, [body], [backorder]."""
    class S:
        def get(self, url, **kw):
            if url.startswith(market.API):
                if url.endswith("/sets"):
                    return R(TCG_SETS)
                if "/sets/" in url:
                    return R({"cards": [{"id": k} for k in TCG_CARDS]})
                return R(TCG_CARDS[url.rsplit("/", 1)[1]])
            site = next((s for s in world if url.startswith(s)), None)
            if site is None or world[site] == "blocked":
                return R(None, 403)
            q = unquote(url.split("search=")[-1].split("&")[0] if "search=" in url
                        else url.split("q=")[1].split("&")[0]).lower()
            words = [w for w in q.split() if w not in ("box", "bundle", "collezione", "set", "allenatore",
                                                       "preordine", "novita")] or q.split()
            hits = [p for p in world[site] if all(w in watch.norm(p["titolo"]) for w in words)]
            if "wp-json" in url:
                return R([{"name": p["titolo"], "permalink": f"{site}/prodotto/{p['h']}/",
                           "is_in_stock": p["comprabile"], "is_purchasable": True,
                           "is_on_backorder": p.get("backorder", False),
                           "short_description": p.get("body", ""),
                           "prices": {"price": str(int(round(p["prezzo"] * 100))), "currency_minor_unit": 2}}
                          for p in hits])
            return R({"resources": {"results": {"products": [
                {"title": p["titolo"], "url": f"/products/{p['h']}?_pos=1", "available": p["comprabile"],
                 "price": f"{p['prezzo']:.2f}", "body": p.get("body", ""), "tags": ["Pokémon"]}
                for p in hits[:10]]}}})
    return S


def run(world, cfg, st, when, env=None):
    watch.requests.Session = make_session(world)
    market.requests.Session = make_session(world)
    watch.CONFIG_FILE, watch.STATE_FILE = cfg, st

    class FakeDT(datetime):
        @classmethod
        def now(cls, tz=None):
            return when

    watch.datetime = FakeDT
    sent = []
    watch.send = lambda token, chat, text, button=None: sent.append((text, button))
    os.environ["TELEGRAM_TOKEN"] = "x"
    os.environ["FORCE_SUMMARY"] = ""
    os.environ.update(env or {})
    watch.main()
    return sent


def at(d, h):
    return datetime(d.year, d.month, d.day, h, 20, tzinfo=watch.TZ)


def test_end_to_end():
    cfg = TMP / "cfg.json"
    cfg.write_text(json.dumps({
        "negozi": [{"nome": "Magic", "sito": "https://m.it", "tipo": "woo", "spedizione": 5.9, "gratis_da": 69},
                   {"nome": "Verse", "sito": "https://v.it", "tipo": "shopify", "spedizione": 5.9, "gratis_da": 150},
                   {"nome": "Nox", "sito": "https://n.it", "tipo": "shopify", "spedizione": None, "gratis_da": 80},
                   {"nome": "Muto", "sito": "https://x.it", "tipo": "woo"}],
        "set": [{"nome": "Dominio Delta", "cerca": "dominio delta", "en": "Delta Reign",
                 "uscita": "2026-11-06", "certo": True},
                {"nome": "Buio Pesto", "cerca": "buio pesto", "en": "Pitch Black", "uscita": "2026-07-17", "certo": True},
                {"nome": "30° Anniversario", "cerca": "30 anniversario", "alias": ["30th"],
                 "uscita": "2026-09-16", "certo": True, "speciale": True}],
        "calendario": [{"data": "2026-10-06", "set": "30° Anniversario", "cosa": "Mini Tin", "stima": True}],
        "soglie": {"Box 36 buste": 200, "Set Allenatore": 60, "Bundle 6 buste": 40, "Ultra Premium": 235},
        "tolleranza_collezione": 1.5, "affare_buste": 1.0}))
    st = TMP / "st.json"
    # stato della versione precedente (v2): il primo giro v3 non deve mandare avvisi
    st.write_text(json.dumps({"versione": 2, "offerte": {}, "negozi_visti": ["Magic", "Verse", "Nox"],
                              "ultimo_riepilogo": "2026-09-27"}))
    world = {
        "https://m.it": [
            {"titolo": "Pokémon Dominio Delta Box 36 bustine ITA", "h": "ddbox", "comprabile": True, "prezzo": 189.9},
            {"titolo": "Pokémon Buio Pesto Box 36 bustine ITA", "h": "bpbox", "comprabile": True, "prezzo": 184.9},
        ],
        "https://v.it": [
            {"titolo": "Pokémon - Megaevoluzione Dominio Delta Booster Box 36 Buste (IT)", "h": "ddbox",
             "comprabile": False, "prezzo": 216.9, "body": "Uscita prevista: 6 novembre 2026"},
            {"titolo": "Pokémon - 30° Anniversario Collezione Ultra Premium Umbreon (ITA)", "h": "upcu",
             "comprabile": False, "prezzo": 229.9},
            {"titolo": "Pokémon - Buio Pesto Bundle 6 Buste (IT)", "h": "bpb", "comprabile": False, "prezzo": 33.9},
        ],
        "https://n.it": [],
        "https://x.it": "blocked",
    }
    day1 = at(TODAY, 15)
    sent = run(world, cfg, st, day1)
    texts = "\n".join(t for t, _ in sent)
    assert "Robot Pokémon v3" in texts and "Preordini aperti" in texts, texts
    assert all(b is None for _, b in sent), "il primo giro deve mandare solo il riepilogo"
    assert "Magic</a> 189,90 €" in texts and "Prossime uscite" in texts
    assert "Valore delle carte" in texts and "Mega Darkrai ex SIR" in texts
    s = json.loads(st.read_text())
    assert s["versione"] == 3 and s["mercato"]["Buio Pesto"]["ev_busta"] > 0
    print("\n=== PRIMO GIRO (aggiornamento) ===\n" + texts)

    # secondo giro: Verse e Nox aprono il preordine del box, Nox mette in scheda un prodotto nuovo,
    # l'Ultra Premium del 30° apre il preordine, il bundle di Buio Pesto torna disponibile
    world["https://v.it"][0]["comprabile"] = True
    world["https://v.it"][1].update(comprabile=True, titolo=world["https://v.it"][1]["titolo"] + " - Preordine")
    world["https://v.it"][2]["comprabile"] = True
    world["https://n.it"] += [
        {"titolo": "Dominio Delta Box 36 Buste ITA", "h": "ddbox", "comprabile": True, "prezzo": 179.9},
        {"titolo": "Dominio Delta Collezione Premium Mega Rayquaza ITA", "h": "ddpc", "comprabile": False,
         "prezzo": 49.9},
    ]
    sent = run(world, cfg, st, at(TODAY, 16))
    print("\n=== SECONDO GIRO ===")
    for t, b in sent:
        print(t, f"\n   [{b[0]}]" if b else "", "\n")
    texts = "\n".join(t for t, _ in sent)
    pre = next(t for t, _ in sent if "Preordine aperto" in t and "Box 36" in t)
    assert "Prenotabile in 3 negozi" in pre and pre.index("Nox") < pre.index("Magic") < pre.index("Verse")
    assert pre.count("appena aperto") == 2 and "Uscita: ven 6 novembre" in pre
    assert "Ultra Premium Umbreon" in texts and "da collezione" in texts
    assert "In arrivo" in texts and "Collezione Premium Rayquaza" in texts
    assert "Di nuovo disponibile" in texts and "Bundle 6 buste" in texts
    assert "☀️" not in texts  # riepilogo già mandato oggi

    # terzo giro, una settimana prima del Mini Tin: promemoria + riepilogo del mattino
    sent = run(world, cfg, st, at(date(2026, 9, 28 + 1), 9))
    texts = "\n".join(t for t, _ in sent)
    assert "Tra una settimana" in texts and "Mini Tin" in texts, texts
    assert "☀️" in texts
    assert not any("Preordine aperto" in t for t, _ in sent)
    print("\n=== TERZO GIRO ===\n" + texts)

    # un prodotto sparisce per un giro (ricerca saltata) e poi ricompare: nessun nuovo avviso
    box = world["https://n.it"].pop(0)
    run(world, cfg, st, at(date(2026, 9, 29), 10))
    world["https://n.it"].insert(0, box)
    sent = run(world, cfg, st, at(date(2026, 9, 29), 11))
    assert not any("Preordine aperto" in t for t, _ in sent), sent


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
